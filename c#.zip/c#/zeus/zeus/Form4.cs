﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zeus
{
    public partial class Form4 : Form
    {
        public static string door, steir="";
        public int front ,left ,right=0;
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            button1.BackColor = Color.Red;
        }

        private void button1_MouseUp(object sender, MouseEventArgs e)
        {
            button1.BackColor = Color.White;
        }

        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            button3.BackColor = Color.Red;
        }

        private void button3_MouseUp(object sender, MouseEventArgs e)
        {
            button3.BackColor = Color.White;
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            button2.BackColor = Color.Red;
        }

        private void button2_MouseUp(object sender, MouseEventArgs e)
        {
            button2.BackColor = Color.White;
        }

        private void button4_MouseDown(object sender, MouseEventArgs e)
        {
            button4.BackColor = Color.Red;
        }

        private void button4_MouseUp(object sender, MouseEventArgs e)
        {
            button4.BackColor = Color.White;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            comboBox1.Text = door;
            comboBox2.Text = steir;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();f6.Show();
        }

        private void pictureBox7_MouseHover(object sender, EventArgs e)
        {
            label9.Visible = true;
        }

        private void pictureBox7_MouseLeave(object sender, EventArgs e)
        {
            label9.Visible = false;
        }

        private void pictureBox6_MouseHover(object sender, EventArgs e)
        {
            label10.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            left++;
            if(front==2 && left == 1)
            {
                pictureBox8.Visible = true;pictureBox5.Visible = false;label3.Visible = false;
                pictureBox9.Visible = false;
                left = 0;
                front = 0;
                MessageBox.Show("MΟΛΙΣ ΕΦΤΑΣΕΣ ΣΤΟ ΠΡΟΑΥΛΙΟ ΤΟΥ ΝΑΟΥ.");
            }
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            right++;
            if (front == 3 && right == 1)
            {
                pictureBox9.Visible = true; pictureBox5.Visible = false; label3.Visible = false;
                pictureBox8.Visible = false;
                right = 0;
                front = 0;
                MessageBox.Show("ΜΟΛΙΣ ΕΦΤΑΣΕΣ ΣΤΟΝ ΚΗΠΟ ΤΟΥ ΟΛΥMΠΟΥ!!");
            }

        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            label11.Visible = true;
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            label11.Visible = false;
        }

        private void button5_MouseHover(object sender, EventArgs e)
        {
            button5.BackColor = Color.Red;
        }

        private void button5_MouseLeave(object sender, EventArgs e)
        {
            button5.BackColor = Color.Indigo;
        }

        private void pictureBox6_MouseLeave(object sender, EventArgs e)
        {
            label10.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            front++;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text.Equals("") || comboBox2.Text.Equals("")) MessageBox.Show("ΛΕΙΠΟΥΝ ΣΤΟΙΧΕΙΑ");
            else
            {
                door = comboBox1.SelectedItem.ToString();
                steir = comboBox2.SelectedItem.ToString();
                MessageBox.Show("ΟΙ ΕΝΤΟΛΕΣ ΕΓΙΝΑΝ ΜΕ ΕΠΙΤΥΧΙΑ");
            }

        }
    }
}
