﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zeus
{
    public partial class Form1 : Form
    {
        public static string name, title,pool;
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ONLINE HELP" + Environment.NewLine +Environment.NewLine+ "ΓΡΑΨΕ ΤΟ ΟΝΟΜΑ ΣΟΥ ΚΑΙ ΕΠΕΛΕΞΕ ΚΑΙ ΙΔΙΟΤΗΤΑ ΓΙΑ ΝΑ ΜΠ" +
                "ΕΙΣ ΣΤΗΝ ΕΦΑΡΜΟΓΗ ΤΟΥ ΠΑΛΑΤΙΟΥ!");
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.Red;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.Indigo;
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            label4.Visible = true;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            label4.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == ""|| comboBox1.Text.Equals("")) MessageBox.Show("ΠΑΡΑΚΑΛΩ ΣΥΜΠΛΗΡΩΣΤΕ ΤΑ ΣΤΟΙXEΙΑ");
            else
            {
                name = textBox1.Text.ToString();
                title = comboBox1.SelectedItem.ToString();
                Random r = new Random();
                int x= r.Next(1, 4);
                pool = x.ToString();
                Form2 F2 = new Form2();
                F2.Show();
            }
            
        }
    }
}
