﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zeus
{
    public partial class Form3 : Form
    {
        public static string cn, ct,p1n,p1t,p2n,p2t,p3n,p3t="f";
        public static bool cp,p1,p2,p3, ca,p1a,p2a,p3a = false;

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            label18.Visible = false;
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.Red;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.Indigo;
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            label18.Visible = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();f5.Show();
        }

        Random random = new Random();
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            if (cp == true)
            {
                comboBox1.Text = cn;
                comboBox2.Text = ct;
                if (cn.Equals("0%")) pictureBox3.Image = Properties.Resources.pool1;
            }
            if (p1 == true)
            {
                comboBox4.Text = p1n;
                comboBox3.Text = p1t;
                if (p1n.Equals("0%")) pictureBox4.Image = Properties.Resources.pool1;
            }
            if (p2 == true)
            {
                comboBox6.Text = p2n;
                comboBox5.Text = p2t;
                if (p2n.Equals("0%")) pictureBox5.Image = Properties.Resources.pool1;
            }
            if (p3 == true)
            {
                comboBox8.Text = p3n;
                comboBox7.Text = p3t;
                if (p3n.Equals("0%")) pictureBox6.Image = Properties.Resources.pool1;
            }
            if (ca == true) { button2.Text = "Alarm ON"; button2.BackColor = Color.Green; }
            else { button2.Text = "Alarm OFF"; button2.BackColor = Color.Red; }
            if (p1a == true) { button3.Text = "Alarm ON"; button3.BackColor = Color.Green; }
            else { button3.Text = "Alarm OFF"; button3.BackColor = Color.Red; }
            if (p2a == true) { button4.Text = "Alarm ON"; button4.BackColor = Color.Green; }
            else { button4.Text = "Alarm OFF"; button4.BackColor = Color.Red; }
            if (p3a == true) { button5.Text = "Alarm ON"; button5.BackColor = Color.Green; }
            else { button5.Text = "Alarm OFF"; button5.BackColor = Color.Red; }
            String x = random.Next(1, 5).ToString();
            String x1 = random.Next(1, 5).ToString();
            String x2 = random.Next(1, 5).ToString();
            String x3 = random.Next(1, 5).ToString();
            if (Form1.title.Equals("PALACE STAFF"))
            {
                if (x.Equals("1"))
                {
                    label14.Visible = true;
                    button6.Enabled = false;
                }
                if (x1.Equals("1"))
                {
                    label15.Visible = true;
                    button7.Enabled = false;
                }
                if (x2.Equals("1"))
                {
                    label16.Visible = true;
                    button8.Enabled = false;
                }
                if (x3.Equals("1"))
                {
                    label17.Visible = true;
                    button9.Enabled = false;
                }
            }


            if (Form1.title.Equals("CUSTOMER"))
            {
                if (Form1.pool.Equals("1"))
                {
                    comboBox1.Enabled = false;
                    comboBox2.Enabled = false;
                    comboBox5.Enabled = false;
                    comboBox6.Enabled = false;
                    comboBox7.Enabled = false;
                    comboBox8.Enabled = false;
                    button2.Enabled = false;
                    button6.Enabled = false;
                    button4.Enabled = false;
                    button8.Enabled = false;
                    button5.Enabled = false;
                    button9.Enabled = false;
                    pictureBox3.Image = Properties.Resources.cam;
                    pictureBox5.Image = Properties.Resources.cam;
                    pictureBox6.Image = Properties.Resources.cam;

                }
                else if (Form1.pool.Equals("2"))
                {
                    comboBox1.Enabled = false;
                    comboBox2.Enabled = false;
                    comboBox3.Enabled = false;
                    comboBox4.Enabled = false;
                    comboBox7.Enabled = false;
                    comboBox8.Enabled = false;
                    pictureBox4.Image = Properties.Resources.cam;
                    pictureBox3.Image = Properties.Resources.cam;
                    pictureBox6.Image = Properties.Resources.cam;
                    button2.Enabled = false;
                    button3.Enabled = false;
                    button5.Enabled = false;
                    button6.Enabled = false;
                    button7.Enabled = false;
                    button9.Enabled = false;
                }
                else if (Form1.pool.Equals("3"))
                {
                    comboBox1.Enabled = false;
                    comboBox2.Enabled = false;
                    comboBox3.Enabled = false;
                    comboBox4.Enabled = false;
                    comboBox6.Enabled = false;
                    comboBox5.Enabled = false;
                    button2.Enabled = false;
                    button4.Enabled = false;
                    button3.Enabled = false;
                    button6.Enabled = false;
                    button8.Enabled = false;
                    button7.Enabled = false;
                    pictureBox3.Image = Properties.Resources.cam;
                    pictureBox4.Image = Properties.Resources.cam;
                    pictureBox5.Image = Properties.Resources.cam;
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (comboBox8.Text.Equals("") || comboBox7.Text.Equals("")) MessageBox.Show("ΣΥΜΠΛΙΡΩΣΕ ΤΑ ΣΤΟΙΧΕΙΑ");
            else
            {
                p3 = true;
                p3n = comboBox8.SelectedItem.ToString();
                p3t = comboBox7.SelectedItem.ToString();
                if (p3n.Equals("0%")) pictureBox6.Image = Properties.Resources.pool1;
                else pictureBox6.Image = Properties.Resources.pool3;
                MessageBox.Show("ΟΙ ΑΛΛΑΓΕΣ ΟΛΟΚΛΗΡΩΘΗΚΑΝ");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.Text.Equals("Alarm OFF")) { ca = true; button2.Text = "Alarm ON";button2.BackColor = Color.Green; }
            else { button2.Text = "Alarm OFF"; ca = false; button2.BackColor = Color.Red; }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (comboBox6.Text.Equals("") || comboBox5.Text.Equals("")) MessageBox.Show("ΣΥΜΠΛΗΡΩΣΕ ΤΑ ΣΤΟΙΧΕΙΑ");
            else
            {
                p2 = true;
                p2n = comboBox6.SelectedItem.ToString();
                p2t = comboBox5.SelectedItem.ToString();
                if (p2n.Equals("0%")) pictureBox5.Image = Properties.Resources.pool1;
                else pictureBox5.Image = Properties.Resources.pool3;
                MessageBox.Show("ΟΙ ΑΛΛΑΓΕΣ ΟΛΟΚΛΗΡΩΘΗΚΑΝ");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text.Equals("Alarm OFF")) { p1a = true; button3.Text = "Alarm ON"; button3.BackColor = Color.Green; }
            else { button3.Text = "Alarm OFF";p1a = false; button3.BackColor = Color.Red; }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text.Equals("") || comboBox2.Text.Equals("")) MessageBox.Show("ΣΥΜΠΛΗΡΩΣΕ ΤΑ ΣΤΟΙΧΕΙΑ");
            else
            {
                cp = true;
                cn = comboBox1.SelectedItem.ToString();
                ct = comboBox2.SelectedItem.ToString();
                if (cn.Equals("0%")) pictureBox3.Image = Properties.Resources.pool1;
                else pictureBox3.Image = Properties.Resources.pool2;
                MessageBox.Show("ΟΙ ΑΛΛΑΓΕΣ ΟΛΟΚΛΗΡΩΘΗΚΑΝ");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (comboBox4.Text.Equals("") || comboBox3.Text.Equals("")) MessageBox.Show("ΣΥΜΠΛΗΡΩΣΕ ΤΑ ΣΤΟΙΧΕΙΑ");
            else
            {
                p1 = true;
                p1n = comboBox4.SelectedItem.ToString();
                p1t = comboBox3.SelectedItem.ToString();
                if (p1n.Equals("0%")) pictureBox4.Image = Properties.Resources.pool1;
                else pictureBox4.Image = Properties.Resources.pool3;
                MessageBox.Show("ΟΙ ΑΛΛΑΓΕΣ ΟΛΟΚΛΗΡΩΘΗΚΑΝ");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.Text.Equals("Alarm OFF")) { p2a = true; button4.Text = "Alarm ON"; button4.BackColor = Color.Green; }
            else { button4.Text = "Alarm OFF";p2a = false; button4.BackColor = Color.Red; }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (button5.Text.Equals("Alarm OFF")) { p3a = true; button5.Text = "Alarm ON"; button5.BackColor = Color.Green; }
            else { button5.Text = "Alarm OFF";p3a = false; button5.BackColor = Color.Red; }
        }
    }
}
