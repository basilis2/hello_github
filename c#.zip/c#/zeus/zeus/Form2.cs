﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zeus
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text ="WELCOME"+" "+ Form1.name;
            label2.Text = Form1.title;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();f3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 f3 = new Form4();f3.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ONLINE HELP" + Environment.NewLine + Environment.NewLine + "" +
                "ΕΠΕΛΕΞΕ ΤΟ ΚΟΥΜΠΙ POOL ΓΙΑ ΤΙΣ ΛΕΙΟΤΥΡΓΙΕΣ ΤΙΣ ΠΙΣΙΝΑΣ Ή ΤΟ ΚΟΥΜΠΙ TROJAN HORSE ΓΙΑ ΤΙΣ ΛΕΙΤΟΥΡΓΙΕΣ ΤΟΥ " +
                "ΔΟΥΡΕΙΟΥ ΙΠΠΟΥ!!");
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            label4.Visible = true;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            label4.Visible = false;
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.Red;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.Indigo;
        }
    }
}
